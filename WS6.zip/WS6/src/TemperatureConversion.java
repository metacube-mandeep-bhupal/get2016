

import javax.jws.WebMethod;
import javax.jws.WebService;

@WebService
public class TemperatureConversion {

	@WebMethod
	public float fahrenheitToCelsius(float fahren)
	{
		return (float) ((fahren-32)*(5.0/9.0));
	}
}
