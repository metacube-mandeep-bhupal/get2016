package DefaultNamespace;

import java.rmi.RemoteException;

import javax.xml.rpc.ServiceException;

public class MyClient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		TemperatureConversionServiceLocator ob=new TemperatureConversionServiceLocator();
		ob.setTemperatureConversionEndpointAddress("http://localhost:8080/WS6/services/TemperatureConversion");
		
		TemperatureConversion tc = null;
		try {
			tc=ob.getTemperatureConversion();
		} catch (ServiceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			System.out.println(tc.fahrenheitToCelsius(89));
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
